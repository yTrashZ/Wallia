import Link from "next/link";
import {
  Files,
  Scissors,
  Minimize2,
  Image as ImageIcon,
  FileImage,
  RotateCw,
  FileMinus,
  FileOutput,
  ShieldCheck,
  Zap,
  MousePointerClick,
  ArrowRight,
} from "lucide-react";
import ToolCard from "@/components/ToolCard";
import FAQ from "@/components/FAQ";

const toolIcons = {
  "juntar-pdf": Files,
  "dividir-pdf": Scissors,
  "comprimir-pdf": Minimize2,
  "pdf-para-jpg": ImageIcon,
  "jpg-para-pdf": FileImage,
  "girar-pdf": RotateCw,
  "remover-paginas": FileMinus,
  "extrair-paginas": FileOutput,
};

import { tools } from "@/lib/tools";

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="mx-auto max-w-content px-4 pb-16 pt-16 sm:px-6 sm:pt-24">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-semibold tracking-tight text-ink-950 sm:text-5xl">
            Ferramentas digitais.
            <br />
            Simples e rápidas.
          </h1>
          <p className="mx-auto mt-5 max-w-lg text-lg text-mist-400">
            Transforme, organize e gerencie seus documentos em poucos cliques.
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              href="/ferramentas"
              className="w-full rounded-full bg-ink-950 px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent sm:w-auto"
            >
              Explorar ferramentas
            </Link>
            <Link
              href="/ferramentas/juntar-pdf"
              className="w-full rounded-full border border-ink-800/15 px-7 py-3.5 text-sm font-semibold text-ink-950 transition-colors hover:border-ink-950 sm:w-auto"
            >
              Começar agora
            </Link>
          </div>
        </div>

        {/* mini preview de cards */}
        <div className="mx-auto mt-16 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
          {tools.slice(0, 4).map((tool) => {
            const Icon = toolIcons[tool.slug as keyof typeof toolIcons];
            return (
              <div
                key={tool.slug}
                className="flex flex-col items-center gap-2 rounded-xl border border-ink-800/10 bg-white px-3 py-5 text-center shadow-card"
              >
                <Icon size={20} className="text-accent" strokeWidth={1.75} />
                <span className="text-xs font-medium text-ink-800">{tool.title}</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* FERRAMENTAS POPULARES */}
      <section className="mx-auto max-w-content px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">
            Ferramentas populares
          </h2>
          <Link
            href="/ferramentas"
            className="hidden items-center gap-1 text-sm font-medium text-accent sm:flex"
          >
            Ver todas <ArrowRight size={15} />
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {tools.map((tool) => (
            <ToolCard
              key={tool.slug}
              title={tool.title}
              description={tool.description}
              icon={toolIcons[tool.slug as keyof typeof toolIcons]}
              href={`/ferramentas/${tool.slug}`}
              available={tool.available}
            />
          ))}
        </div>
      </section>

      {/* POR QUE WALL.IA */}
      <section className="border-y border-ink-800/10 bg-ink-950/[0.015]">
        <div className="mx-auto max-w-content px-4 py-16 sm:px-6">
          <h2 className="text-center text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">
            Por que Wall.IA?
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
            {[
              {
                icon: ShieldCheck,
                title: "Privacidade",
                text: "Sempre que possível, seus arquivos são processados no seu próprio dispositivo.",
              },
              {
                icon: Zap,
                title: "Rápido",
                text: "Sem filas de upload: o processamento acontece direto no navegador.",
              },
              {
                icon: MousePointerClick,
                title: "Fácil de usar",
                text: "Interface simples, sem etapas desnecessárias ou telas confusas.",
              },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl bg-white p-6 shadow-card">
                <item.icon size={22} className="text-accent" strokeWidth={1.75} />
                <h3 className="mt-3 text-base font-semibold text-ink-950">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-mist-400">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="mx-auto max-w-content px-4 py-16 sm:px-6">
        <h2 className="text-center text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">
          Como funciona?
        </h2>
        <div className="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-4">
          {[
            "Escolha uma ferramenta",
            "Envie seu arquivo",
            "Processe",
            "Baixe o resultado",
          ].map((step, i) => (
            <div key={step} className="text-center">
              <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-ink-950 text-sm font-semibold text-white">
                {i + 1}
              </div>
              <p className="mt-3 text-sm font-medium text-ink-900">{step}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PRIVACIDADE */}
      <section className="border-y border-ink-800/10 bg-ink-950/[0.015]">
        <div className="mx-auto max-w-content px-4 py-16 sm:px-6">
          <div className="mx-auto max-w-2xl text-center">
            <ShieldCheck size={28} className="mx-auto text-accent" strokeWidth={1.5} />
            <h2 className="mt-4 text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">
              Seus documentos são importantes.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-mist-400">
              Sempre que possível, o Wall.IA processa seus arquivos diretamente no seu
              dispositivo. Isso reduz a necessidade de enviar seus documentos para
              servidores externos. Seus arquivos são processados diretamente no seu
              dispositivo sempre que possível.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-content px-4 py-16 sm:px-6">
        <h2 className="text-center text-2xl font-semibold tracking-tight text-ink-950 sm:text-3xl">
          Perguntas frequentes
        </h2>
        <div className="mt-10">
          <FAQ />
        </div>
      </section>
    </>
  );
}
