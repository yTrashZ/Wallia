"use client";

import { useState } from "react";
import ToolPageHeader from "@/components/ToolPageHeader";
import FileUploader from "@/components/FileUploader";
import ProcessingStatus from "@/components/ProcessingStatus";
import DownloadButton from "@/components/DownloadButton";
import { compressPdf, type CompressResult } from "@/lib/pdf/compress";
import { formatBytes } from "@/lib/tools";
import type { ProcessingState } from "@/types";
import { Info } from "lucide-react";

export default function ComprimirPdfPage() {
  const [state, setState] = useState<ProcessingState>({ status: "idle" });
  const [result, setResult] = useState<CompressResult | null>(null);

  async function handleFile(files: File[]) {
    const f = files[0];
    setResult(null);
    setState({ status: "processing", message: "Compactando seu PDF..." });
    try {
      const compressed = await compressPdf(f);
      setResult(compressed);
      setState({ status: "done", message: "Seu PDF está pronto." });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Não foi possível processar este arquivo.",
      });
    }
  }

  function reset() {
    setResult(null);
    setState({ status: "idle" });
  }

  const saved = result ? result.originalSize - result.finalSize : 0;
  const savedPct = result && result.originalSize > 0 ? (saved / result.originalSize) * 100 : 0;

  return (
    <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <ToolPageHeader
        title="Comprimir PDF"
        description="Reduza o tamanho do seu PDF mantendo a qualidade."
      />

      <div className="mt-6 flex items-start gap-3 rounded-xl border border-accent/20 bg-accent/5 px-4 py-3.5 text-left">
        <Info size={17} className="mt-0.5 flex-shrink-0 text-accent" />
        <p className="text-xs leading-relaxed text-ink-700">
          A compressão acontece 100% no seu navegador, sem servidor. Ela remove
          metadados e otimiza a estrutura interna do arquivo. Como não recomprimimos
          imagens internas, a redução pode ser pequena em PDFs que já estão
          otimizados ou que têm poucas imagens — mostramos sempre o resultado real.
        </p>
      </div>

      <div className="mt-6">
        {!result && (
          <FileUploader
            accept=".pdf"
            onFilesSelected={handleFile}
            onError={(msg) => setState({ status: "error", message: msg })}
            hint="Apenas arquivos .pdf, até 100 MB."
          />
        )}

        <ProcessingStatus state={state} />

        {result && (
          <div className="text-center">
            <div className="mx-auto mt-2 grid max-w-sm grid-cols-3 gap-3">
              <div className="rounded-xl border border-ink-800/10 px-3 py-4">
                <p className="text-xs text-mist-400">Original</p>
                <p className="mt-1 text-sm font-semibold text-ink-950">
                  {formatBytes(result.originalSize)}
                </p>
              </div>
              <div className="rounded-xl border border-ink-800/10 px-3 py-4">
                <p className="text-xs text-mist-400">Final</p>
                <p className="mt-1 text-sm font-semibold text-ink-950">
                  {formatBytes(result.finalSize)}
                </p>
              </div>
              <div className="rounded-xl border border-ink-800/10 px-3 py-4">
                <p className="text-xs text-mist-400">Economia</p>
                <p className="mt-1 text-sm font-semibold text-ink-950">
                  {saved > 0 ? `${savedPct.toFixed(0)}%` : "0%"}
                </p>
              </div>
            </div>

            <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <DownloadButton
                blob={result.blob}
                filename="documento-comprimido.pdf"
                label="Baixar PDF"
              />
              <button
                type="button"
                onClick={reset}
                className="w-full rounded-full border border-ink-800/15 px-6 py-3.5 text-sm font-semibold text-ink-950 sm:w-auto"
              >
                Processar outro arquivo
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
