"use client";

import { useState, type ChangeEvent } from "react";
import ToolPageHeader from "@/components/ToolPageHeader";
import FileUploader from "@/components/FileUploader";
import ProcessingStatus from "@/components/ProcessingStatus";
import DownloadButton from "@/components/DownloadButton";
import { getPdfPageCount } from "@/lib/pdf/split";
import { pdfToImages, type PdfToImagesResult } from "@/lib/pdf/pdfToImages";
import { parsePageRanges } from "@/lib/pdf/parsePageRanges";
import type { ProcessingState } from "@/types";
import { FileText } from "lucide-react";

export default function PdfParaJpgPage() {
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [mode, setMode] = useState<"todas" | "especificas">("todas");
  const [rangeInput, setRangeInput] = useState("");
  const [state, setState] = useState<ProcessingState>({ status: "idle" });
  const [result, setResult] = useState<PdfToImagesResult | null>(null);

  async function handleFile(files: File[]) {
    const f = files[0];
    setResult(null);
    setState({ status: "idle" });
    setFile(f);
    try {
      const count = await getPdfPageCount(f);
      setPageCount(count);
    } catch {
      setState({ status: "error", message: "Este arquivo não é um PDF válido." });
      setFile(null);
    }
  }

  async function handleConvert() {
    if (!file || !pageCount) return;
    setState({ status: "processing", message: "Convertendo páginas em imagens...", progress: 0 });
    try {
      const pages = mode === "todas" ? null : parsePageRanges(rangeInput, pageCount);
      const res = await pdfToImages(file, pages, (fraction) =>
        setState({
          status: "processing",
          message: "Convertendo páginas em imagens...",
          progress: fraction,
        })
      );
      setResult(res);
      setState({ status: "done", message: "Suas imagens estão prontas." });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Não foi possível processar este arquivo.",
      });
    }
  }

  function reset() {
    setFile(null);
    setPageCount(null);
    setRangeInput("");
    setResult(null);
    setState({ status: "idle" });
  }

  return (
    <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <ToolPageHeader
        title="PDF para JPG"
        description="Converta páginas do PDF em imagens JPG."
      />

      <div className="mt-10">
        {!file && (
          <FileUploader
            accept=".pdf"
            onFilesSelected={handleFile}
            onError={(msg) => setState({ status: "error", message: msg })}
            hint="Apenas arquivos .pdf, até 100 MB."
          />
        )}

        {file && pageCount && !result && (
          <div>
            <div className="flex items-center gap-3 rounded-xl border border-ink-800/10 bg-white px-4 py-3.5">
              <FileText size={18} className="text-ink-700" />
              <div className="flex-1">
                <p className="text-sm font-medium text-ink-900">{file.name}</p>
                <p className="text-xs text-mist-400">{pageCount} páginas</p>
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                type="button"
                onClick={() => setMode("todas")}
                className={`flex-1 rounded-full px-4 py-2.5 text-sm font-medium ${
                  mode === "todas" ? "bg-ink-950 text-white" : "bg-ink-950/[0.05] text-ink-700"
                }`}
              >
                Todas as páginas
              </button>
              <button
                type="button"
                onClick={() => setMode("especificas")}
                className={`flex-1 rounded-full px-4 py-2.5 text-sm font-medium ${
                  mode === "especificas" ? "bg-ink-950 text-white" : "bg-ink-950/[0.05] text-ink-700"
                }`}
              >
                Páginas específicas
              </button>
            </div>

            {mode === "especificas" && (
              <input
                type="text"
                value={rangeInput}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setRangeInput(e.target.value)}
                placeholder="Ex: 1-3, 5"
                className="mt-4 w-full rounded-xl border border-ink-800/15 px-4 py-3 text-sm focus:border-accent"
              />
            )}

            <ProcessingStatus state={state} />

            {state.status !== "processing" && (
              <button
                type="button"
                onClick={handleConvert}
                disabled={mode === "especificas" && !rangeInput.trim()}
                className="mt-6 w-full rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
              >
                Converter para JPG
              </button>
            )}
          </div>
        )}

        {result && (
          <div className="text-center">
            <ProcessingStatus state={state} />
            <p className="mt-2 text-sm text-mist-400">
              {result.pageCount} imagem(ns) gerada(s)
              {result.isZip ? " — empacotadas em um .zip." : "."}
            </p>
            <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <DownloadButton
                blob={result.blob}
                filename={result.filename}
                label={result.isZip ? "Baixar .zip" : "Baixar imagem"}
              />
              <button
                type="button"
                onClick={reset}
                className="w-full rounded-full border border-ink-800/15 px-6 py-3.5 text-sm font-semibold text-ink-950 sm:w-auto"
              >
                Processar outro arquivo
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
