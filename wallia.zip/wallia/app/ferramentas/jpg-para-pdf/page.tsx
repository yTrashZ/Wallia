"use client";

import { useState } from "react";
import ToolPageHeader from "@/components/ToolPageHeader";
import FileUploader from "@/components/FileUploader";
import FileList from "@/components/FileList";
import ProcessingStatus from "@/components/ProcessingStatus";
import DownloadButton from "@/components/DownloadButton";
import { imagesToPdf } from "@/lib/pdf/imagesToPdf";
import type { ManagedFile, ProcessingState } from "@/types";

let idCounter = 0;
const nextId = () => `img-${Date.now()}-${idCounter++}`;

export default function JpgParaPdfPage() {
  const [files, setFiles] = useState<ManagedFile[]>([]);
  const [state, setState] = useState<ProcessingState>({ status: "idle" });
  const [result, setResult] = useState<Blob | null>(null);

  function addFiles(newFiles: File[]) {
    setState({ status: "idle" });
    setResult(null);
    setFiles((prev) => [...prev, ...newFiles.map((file) => ({ id: nextId(), file }))]);
  }

  function removeFile(id: string) {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  async function handleConvert() {
    setState({ status: "processing", message: "Criando seu PDF..." });
    try {
      const blob = await imagesToPdf(files.map((f) => f.file));
      setResult(blob);
      setState({ status: "done", message: "Seu PDF está pronto." });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Não foi possível processar este arquivo.",
      });
    }
  }

  function reset() {
    setFiles([]);
    setResult(null);
    setState({ status: "idle" });
  }

  return (
    <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <ToolPageHeader
        title="JPG para PDF"
        description="Transforme imagens em um documento PDF."
      />

      <div className="mt-10">
        {!result && (
          <>
            <FileUploader
              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
              multiple
              onFilesSelected={addFiles}
              onError={(msg) => setState({ status: "error", message: msg })}
              hint="JPG, JPEG, PNG ou WEBP, até 100 MB cada."
            />

            <FileList files={files} onRemove={removeFile} onReorder={setFiles} reorderable />

            <ProcessingStatus state={state} />

            {files.length >= 1 && state.status !== "processing" && (
              <button
                type="button"
                onClick={handleConvert}
                className="mt-6 w-full rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent"
              >
                Criar PDF
              </button>
            )}
          </>
        )}

        {result && (
          <div className="text-center">
            <ProcessingStatus state={state} />
            <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <DownloadButton blob={result} filename="imagens-convertidas.pdf" label="Baixar PDF" />
              <button
                type="button"
                onClick={reset}
                className="w-full rounded-full border border-ink-800/15 px-6 py-3.5 text-sm font-semibold text-ink-950 sm:w-auto"
              >
                Processar outro arquivo
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
