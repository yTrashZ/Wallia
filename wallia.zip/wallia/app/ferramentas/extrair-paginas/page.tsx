"use client";

import { useState, type ChangeEvent } from "react";
import ToolPageHeader from "@/components/ToolPageHeader";
import FileUploader from "@/components/FileUploader";
import ProcessingStatus from "@/components/ProcessingStatus";
import DownloadButton from "@/components/DownloadButton";
import { getPdfPageCount } from "@/lib/pdf/split";
import { extractPages } from "@/lib/pdf/extractPages";
import { parsePageRanges } from "@/lib/pdf/parsePageRanges";
import type { ProcessingState } from "@/types";
import { FileText } from "lucide-react";

export default function ExtrairPaginasPage() {
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [rangeInput, setRangeInput] = useState("");
  const [state, setState] = useState<ProcessingState>({ status: "idle" });
  const [result, setResult] = useState<Blob | null>(null);

  async function handleFile(files: File[]) {
    const f = files[0];
    setResult(null);
    setState({ status: "idle" });
    setFile(f);
    try {
      const count = await getPdfPageCount(f);
      setPageCount(count);
    } catch {
      setState({ status: "error", message: "Este arquivo não é um PDF válido." });
      setFile(null);
    }
  }

  async function handleExtract() {
    if (!file || !pageCount) return;
    setState({ status: "processing", message: "Extraindo páginas..." });
    try {
      const pages = parsePageRanges(rangeInput, pageCount);
      const blob = await extractPages(file, pages);
      setResult(blob);
      setState({ status: "done", message: "Seu PDF está pronto." });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Não foi possível processar este arquivo.",
      });
    }
  }

  function reset() {
    setFile(null);
    setPageCount(null);
    setRangeInput("");
    setResult(null);
    setState({ status: "idle" });
  }

  return (
    <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <ToolPageHeader
        title="Extrair páginas"
        description="Extraia páginas específicas e crie um novo PDF."
      />

      <div className="mt-10">
        {!file && (
          <FileUploader
            accept=".pdf"
            onFilesSelected={handleFile}
            onError={(msg) => setState({ status: "error", message: msg })}
            hint="Apenas arquivos .pdf, até 100 MB."
          />
        )}

        {file && pageCount && !result && (
          <div>
            <div className="flex items-center gap-3 rounded-xl border border-ink-800/10 bg-white px-4 py-3.5">
              <FileText size={18} className="text-ink-700" />
              <div className="flex-1">
                <p className="text-sm font-medium text-ink-900">{file.name}</p>
                <p className="text-xs text-mist-400">{pageCount} páginas</p>
              </div>
            </div>

            <label className="mt-6 block text-sm font-medium text-ink-900">
              Quais páginas você quer extrair?
            </label>
            <input
              type="text"
              value={rangeInput}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setRangeInput(e.target.value)}
              placeholder="Ex: 1-3, 5"
              className="mt-2 w-full rounded-xl border border-ink-800/15 px-4 py-3 text-sm focus:border-accent"
            />

            <ProcessingStatus state={state} />

            {state.status !== "processing" && (
              <button
                type="button"
                onClick={handleExtract}
                disabled={!rangeInput.trim()}
                className="mt-6 w-full rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
              >
                Extrair páginas
              </button>
            )}
          </div>
        )}

        {result && (
          <div className="text-center">
            <ProcessingStatus state={state} />
            <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <DownloadButton blob={result} filename="paginas-extraidas.pdf" label="Baixar PDF" />
              <button
                type="button"
                onClick={reset}
                className="w-full rounded-full border border-ink-800/15 px-6 py-3.5 text-sm font-semibold text-ink-950 sm:w-auto"
              >
                Processar outro arquivo
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
