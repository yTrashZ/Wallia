"use client";

import { useState } from "react";
import {
  Files,
  Scissors,
  Minimize2,
  Image as ImageIcon,
  FileImage,
  RotateCw,
  FileMinus,
  FileOutput,
} from "lucide-react";
import ToolCard from "@/components/ToolCard";
import { tools } from "@/lib/tools";

const toolIcons = {
  "juntar-pdf": Files,
  "dividir-pdf": Scissors,
  "comprimir-pdf": Minimize2,
  "pdf-para-jpg": ImageIcon,
  "jpg-para-pdf": FileImage,
  "girar-pdf": RotateCw,
  "remover-paginas": FileMinus,
  "extrair-paginas": FileOutput,
};

const categories = [
  { value: "todos", label: "Todos" },
  { value: "pdf", label: "PDF" },
  { value: "imagem", label: "Imagem" },
  { value: "documentos", label: "Documentos" },
  { value: "texto", label: "Texto" },
] as const;

export default function FerramentasPage() {
  const [category, setCategory] = useState<string>("todos");

  const filtered =
    category === "todos" ? tools : tools.filter((t) => t.category === category);

  const showComingSoonNotice = category !== "todos" && category !== "pdf";

  return (
    <section className="mx-auto max-w-content px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
          Ferramentas
        </h1>
        <p className="mt-3 text-base text-mist-400">
          Escolha uma ferramenta e processe seu arquivo diretamente no navegador.
        </p>
      </div>

      <div className="mx-auto mt-8 flex max-w-2xl flex-wrap justify-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat.value}
            type="button"
            onClick={() => setCategory(cat.value)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
              category === cat.value
                ? "bg-ink-950 text-white"
                : "bg-ink-950/[0.05] text-ink-700 hover:bg-ink-950/[0.08]"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {showComingSoonNotice && (
        <p className="mx-auto mt-8 max-w-md text-center text-sm text-mist-400">
          Ferramentas de {categories.find((c) => c.value === category)?.label} ainda
          não estão disponíveis — estão em desenvolvimento.
        </p>
      )}

      <div className="mx-auto mt-10 grid max-w-content grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {filtered.map((tool) => (
          <ToolCard
            key={tool.slug}
            title={tool.title}
            description={tool.description}
            icon={toolIcons[tool.slug as keyof typeof toolIcons]}
            href={`/ferramentas/${tool.slug}`}
            available={tool.available}
          />
        ))}
      </div>
    </section>
  );
}
