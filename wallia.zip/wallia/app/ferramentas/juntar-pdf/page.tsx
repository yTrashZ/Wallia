"use client";

import { useState } from "react";
import ToolPageHeader from "@/components/ToolPageHeader";
import FileUploader from "@/components/FileUploader";
import FileList from "@/components/FileList";
import ProcessingStatus from "@/components/ProcessingStatus";
import DownloadButton from "@/components/DownloadButton";
import { mergePdfs } from "@/lib/pdf/merge";
import type { ManagedFile, ProcessingState } from "@/types";

let idCounter = 0;
const nextId = () => `f-${Date.now()}-${idCounter++}`;

export default function JuntarPdfPage() {
  const [files, setFiles] = useState<ManagedFile[]>([]);
  const [state, setState] = useState<ProcessingState>({ status: "idle" });
  const [result, setResult] = useState<Blob | null>(null);

  function addFiles(newFiles: File[]) {
    setState({ status: "idle" });
    setResult(null);
    setFiles((prev) => [...prev, ...newFiles.map((file) => ({ id: nextId(), file }))]);
  }

  function removeFile(id: string) {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  async function handleMerge() {
    setResult(null);
    setState({ status: "processing", message: "Juntando seus PDFs..." });
    try {
      const blob = await mergePdfs(
        files.map((f) => f.file),
        (fraction) =>
          setState({
            status: "processing",
            message: "Juntando seus PDFs...",
            progress: fraction,
          })
      );
      setResult(blob);
      setState({ status: "done", message: "Seu PDF está pronto." });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Não foi possível processar este arquivo.",
      });
    }
  }

  function reset() {
    setFiles([]);
    setResult(null);
    setState({ status: "idle" });
  }

  return (
    <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
      <ToolPageHeader
        title="Juntar PDF"
        description="Combine vários arquivos PDF em um único documento."
      />

      <div className="mt-10">
        {!result && (
          <>
            <FileUploader
              accept=".pdf"
              multiple
              onFilesSelected={addFiles}
              onError={(msg) => setState({ status: "error", message: msg })}
              hint="Apenas arquivos .pdf, até 100 MB cada."
            />

            <FileList files={files} onRemove={removeFile} onReorder={setFiles} reorderable />

            <ProcessingStatus state={state} />

            {files.length >= 2 && state.status !== "processing" && (
              <button
                type="button"
                onClick={handleMerge}
                className="mt-6 w-full rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent"
              >
                Juntar PDFs
              </button>
            )}
            {files.length === 1 && (
              <p className="mt-4 text-center text-sm text-mist-400">
                Adicione mais um PDF para poder juntá-los.
              </p>
            )}
          </>
        )}

        {result && (
          <div className="text-center">
            <ProcessingStatus state={state} />
            <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
              <DownloadButton blob={result} filename="documento-unido.pdf" label="Baixar PDF" />
              <button
                type="button"
                onClick={reset}
                className="w-full rounded-full border border-ink-800/15 px-6 py-3.5 text-sm font-semibold text-ink-950 sm:w-auto"
              >
                Processar outro arquivo
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
