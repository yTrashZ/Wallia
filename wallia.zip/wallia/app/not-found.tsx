import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto flex max-w-content flex-col items-center px-4 py-32 text-center sm:px-6">
      <p className="text-sm font-semibold text-accent">404</p>
      <h1 className="mt-3 text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
        Ops! Essa página não existe.
      </h1>
      <Link
        href="/"
        className="mt-8 rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent"
      >
        Voltar para o início
      </Link>
    </section>
  );
}
