import type { MetadataRoute } from "next";
import { tools } from "@/lib/tools";

const baseUrl = "https://wallia.app";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = ["", "/ferramentas", "/sobre", "/privacidade", "/termos"].map(
    (path) => ({
      url: `${baseUrl}${path}`,
      lastModified: new Date(),
    })
  );

  const toolRoutes = tools.map((tool) => ({
    url: `${baseUrl}/ferramentas/${tool.slug}`,
    lastModified: new Date(),
  }));

  return [...staticRoutes, ...toolRoutes];
}
