import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const siteUrl = "https://wallia.app";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Wall.IA — Ferramentas online para PDF e documentos",
    template: "%s | Wall.IA",
  },
  description:
    "Junte, divida, comprima e transforme seus documentos com ferramentas online simples, rápidas e fáceis de usar.",
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "Wall.IA — Ferramentas online para PDF e documentos",
    description:
      "Junte, divida, comprima e transforme seus documentos com ferramentas online simples, rápidas e fáceis de usar.",
    url: siteUrl,
    siteName: "Wall.IA",
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Wall.IA — Ferramentas online para PDF e documentos",
    description:
      "Junte, divida, comprima e transforme seus documentos com ferramentas online simples, rápidas e fáceis de usar.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="flex min-h-screen flex-col bg-white text-ink-950 antialiased">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
