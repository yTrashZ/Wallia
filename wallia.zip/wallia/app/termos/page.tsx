import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Termos de uso",
  description: "Termos de uso do Wall.IA.",
};

export default function TermosPage() {
  return (
    <section className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      <h1 className="text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
        Termos de uso
      </h1>
      <div className="mt-6 space-y-4 text-base leading-relaxed text-mist-400">
        <p>
          Ao usar o Wall.IA, você concorda em utilizar as ferramentas disponíveis de
          forma lícita e responsável, apenas com arquivos que você tem o direito de
          processar.
        </p>
        <p>
          As ferramentas são fornecidas "como estão". Fazemos o possível para que o
          processamento funcione corretamente, mas recomendamos manter uma cópia de
          segurança dos seus arquivos originais antes de qualquer edição.
        </p>
        <p>
          O Wall.IA está em desenvolvimento contínuo, e novas ferramentas e
          categorias serão adicionadas ao longo do tempo.
        </p>
      </div>
    </section>
  );
}
