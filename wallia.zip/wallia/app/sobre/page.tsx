import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Sobre",
  description: "Conheça a proposta do Wall.IA.",
};

export default function SobrePage() {
  return (
    <section className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      <h1 className="text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
        Sobre o Wall.IA
      </h1>
      <div className="mt-6 space-y-4 text-base leading-relaxed text-mist-400">
        <p>
          O Wall.IA nasceu para tornar tarefas digitais comuns — como juntar, dividir
          ou converter um PDF — mais simples, rápidas e diretas, sem etapas
          desnecessárias.
        </p>
        <p>
          A ideia é reunir, aos poucos, ferramentas úteis para documentos, imagens,
          texto e produtividade em um único lugar, com uma interface limpa e sem
          distrações.
        </p>
        <p>
          Sempre que tecnicamente possível, o processamento dos seus arquivos acontece
          diretamente no seu navegador, no seu próprio dispositivo, em vez de depender
          de um servidor externo.
        </p>
        <p>
          O Wall.IA está em desenvolvimento contínuo: novas ferramentas e categorias
          serão adicionadas de forma gradual, sempre priorizando funcionalidade real
          sobre promessas.
        </p>
      </div>
    </section>
  );
}
