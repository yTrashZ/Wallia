import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacidade",
  description: "Como o Wall.IA trata seus arquivos e dados.",
};

export default function PrivacidadePage() {
  return (
    <section className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      <h1 className="text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
        Privacidade
      </h1>
      <div className="mt-6 space-y-4 text-base leading-relaxed text-mist-400">
        <p>
          Sempre que possível, o Wall.IA processa seus arquivos diretamente no seu
          navegador, no seu próprio dispositivo. Isso significa que, para as
          ferramentas de PDF disponíveis hoje, seus documentos não são enviados a
          nenhum servidor durante o processamento.
        </p>
        <p>
          Não afirmamos que absolutamente todas as ferramentas, presentes ou futuras,
          funcionarão dessa forma — caso alguma ferramenta futura precise de
          processamento em servidor, isso será informado claramente na própria
          página da ferramenta.
        </p>
        <p>
          O Wall.IA não armazena permanentemente os arquivos que você processa. Os
          resultados gerados existem apenas na memória do seu navegador até que você
          faça o download ou feche a página.
        </p>
      </div>
    </section>
  );
}
