"use client";

import { FileText, X, ChevronUp, ChevronDown } from "lucide-react";
import { formatBytes } from "@/lib/tools";
import type { ManagedFile } from "@/types";

interface FileListProps {
  files: ManagedFile[];
  onRemove: (id: string) => void;
  onReorder?: (newOrder: ManagedFile[]) => void;
  reorderable?: boolean;
}

export default function FileList({
  files,
  onRemove,
  onReorder,
  reorderable = false,
}: FileListProps) {
  if (files.length === 0) return null;

  function move(index: number, direction: -1 | 1) {
    if (!onReorder) return;
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= files.length) return;
    const next = [...files];
    [next[index], next[newIndex]] = [next[newIndex], next[index]];
    onReorder(next);
  }

  return (
    <ul className="mt-6 space-y-2">
      {files.map((mf, index) => (
        <li
          key={mf.id}
          className="flex items-center gap-3 rounded-xl border border-ink-800/10 bg-white px-4 py-3"
        >
          <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-ink-950/[0.04] text-ink-700">
            <FileText size={17} />
          </div>

          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-ink-900">{mf.file.name}</p>
            <p className="text-xs text-mist-400">{formatBytes(mf.file.size)}</p>
          </div>

          {reorderable && (
            <div className="flex flex-shrink-0 flex-col">
              <button
                type="button"
                aria-label="Mover para cima"
                disabled={index === 0}
                onClick={() => move(index, -1)}
                className="p-1 text-ink-700 disabled:opacity-25"
              >
                <ChevronUp size={16} />
              </button>
              <button
                type="button"
                aria-label="Mover para baixo"
                disabled={index === files.length - 1}
                onClick={() => move(index, 1)}
                className="p-1 text-ink-700 disabled:opacity-25"
              >
                <ChevronDown size={16} />
              </button>
            </div>
          )}

          <button
            type="button"
            aria-label={`Remover ${mf.file.name}`}
            onClick={() => onRemove(mf.id)}
            className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg text-mist-400 hover:bg-red-50 hover:text-red-500"
          >
            <X size={17} />
          </button>
        </li>
      ))}
    </ul>
  );
}
