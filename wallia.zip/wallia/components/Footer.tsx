import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-ink-800/10 bg-ink-950 text-mist-200">
      <div className="mx-auto max-w-content px-4 py-14 sm:px-6">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          <div className="col-span-2">
            <p className="text-lg font-semibold text-white">
              Wall<span className="text-accent-light">.IA</span>
            </p>
            <p className="mt-2 max-w-xs text-sm text-mist-400">
              Ferramentas digitais. Simples e rápidas.
            </p>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Produto</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link href="/ferramentas" className="hover:text-white">Ferramentas</Link></li>
              <li><Link href="/sobre" className="hover:text-white">Sobre</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Legal</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link href="/privacidade" className="hover:text-white">Privacidade</Link></li>
              <li><Link href="/termos" className="hover:text-white">Termos de uso</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-xs text-mist-400">
          © 2026 Wall.IA. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
