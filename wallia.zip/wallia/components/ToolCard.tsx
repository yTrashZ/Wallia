import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import { ArrowRight, Clock } from "lucide-react";

interface ToolCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  available?: boolean;
}

export default function ToolCard({
  title,
  description,
  icon: Icon,
  href,
  available = true,
}: ToolCardProps) {
  const content = (
    <div className="group flex h-full flex-col rounded-2xl border border-ink-800/10 bg-white p-6 shadow-card transition-all hover:-translate-y-0.5 hover:border-accent/30">
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-ink-950/[0.04] text-ink-950 group-hover:bg-accent/10 group-hover:text-accent">
        <Icon size={20} strokeWidth={1.75} />
      </div>
      <h3 className="mt-4 text-base font-semibold text-ink-950">{title}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-mist-400">{description}</p>

      <div className="mt-5 flex items-center text-sm font-medium">
        {available ? (
          <span className="flex items-center gap-1.5 text-ink-950 group-hover:text-accent">
            Usar ferramenta
            <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
          </span>
        ) : (
          <span className="flex items-center gap-1.5 text-mist-400">
            <Clock size={15} />
            Em breve
          </span>
        )}
      </div>
    </div>
  );

  if (!available) {
    return <div className="cursor-not-allowed opacity-70">{content}</div>;
  }

  return (
    <Link href={href} className="block h-full">
      {content}
    </Link>
  );
}
