"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { href: "/", label: "Início" },
  { href: "/ferramentas", label: "Ferramentas" },
  { href: "/ferramentas?categoria=pdf", label: "PDF" },
  { href: "/sobre", label: "Sobre" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-ink-800/10 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-content items-center justify-between px-4 sm:px-6">
        <Link href="/" className="text-lg font-semibold tracking-tight text-ink-950">
          Wall<span className="text-accent">.IA</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-ink-700 transition-colors hover:text-ink-950"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <button
            type="button"
            className="rounded-full px-4 py-2 text-sm font-medium text-ink-700 transition-colors hover:text-ink-950"
          >
            Entrar
          </button>
          <button
            type="button"
            className="rounded-full bg-ink-950 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-accent"
          >
            Criar conta
          </button>
        </div>

        <button
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="flex h-11 w-11 items-center justify-center rounded-full text-ink-950 md:hidden"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <nav className="border-t border-ink-800/10 bg-white px-4 pb-6 pt-2 md:hidden">
          <ul className="flex flex-col">
            {navLinks.map((link) => (
              <li key={link.label}>
                <Link
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block py-3 text-base font-medium text-ink-800"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-col gap-3">
            <button
              type="button"
              className="w-full rounded-full border border-ink-800/15 px-4 py-3 text-sm font-medium text-ink-800"
            >
              Entrar
            </button>
            <button
              type="button"
              className="w-full rounded-full bg-ink-950 px-4 py-3 text-sm font-medium text-white"
            >
              Criar conta
            </button>
          </div>
        </nav>
      )}
    </header>
  );
}
