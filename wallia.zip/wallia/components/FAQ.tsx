"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqItems = [
  {
    question: "Meus arquivos são enviados para algum servidor?",
    answer:
      "As ferramentas de PDF disponíveis hoje no Wall.IA processam seus arquivos diretamente no seu navegador, no seu próprio dispositivo. Eles não são enviados para nenhum servidor durante o processamento. Caso ferramentas futuras precisem de processamento em servidor, isso será informado claramente na própria ferramenta.",
  },
  {
    question: "Quais tipos de arquivos são aceitos?",
    answer:
      "Atualmente o Wall.IA trabalha com arquivos PDF e, em algumas ferramentas, imagens JPG, JPEG, PNG e WEBP. Cada ferramenta informa exatamente quais formatos aceita.",
  },
  {
    question: "Existe limite de tamanho?",
    answer:
      "Sim. Como o processamento acontece no seu dispositivo, definimos um limite inicial de 100 MB por arquivo, para garantir uma experiência estável em celulares e computadores mais simples.",
  },
  {
    question: "Posso usar pelo celular?",
    answer:
      "Sim. O Wall.IA foi construído para funcionar bem em Android, iPhone, tablets e computadores, direto pelo navegador.",
  },
  {
    question: "Preciso instalar algum programa?",
    answer:
      "Não. O Wall.IA funciona inteiramente no navegador, sem necessidade de instalar aplicativos ou extensões.",
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="mx-auto max-w-2xl divide-y divide-ink-800/10">
      {faqItems.map((item, index) => {
        const isOpen = openIndex === index;
        return (
          <div key={item.question}>
            <button
              type="button"
              onClick={() => setOpenIndex(isOpen ? null : index)}
              aria-expanded={isOpen}
              className="flex w-full items-center justify-between gap-4 py-5 text-left"
            >
              <span className="text-base font-medium text-ink-950">{item.question}</span>
              <ChevronDown
                size={18}
                className={`flex-shrink-0 text-mist-400 transition-transform ${
                  isOpen ? "rotate-180" : ""
                }`}
              />
            </button>
            {isOpen && (
              <p className="pb-5 text-sm leading-relaxed text-mist-400">{item.answer}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}
