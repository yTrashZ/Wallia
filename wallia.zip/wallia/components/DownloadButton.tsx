"use client";

import { Download } from "lucide-react";

interface DownloadButtonProps {
  blob: Blob;
  filename: string;
  label?: string;
}

export default function DownloadButton({
  blob,
  filename,
  label = "Baixar arquivo",
}: DownloadButtonProps) {
  function handleDownload() {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    // Libera a URL temporária após o navegador iniciar o download.
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <button
      type="button"
      onClick={handleDownload}
      className="flex w-full items-center justify-center gap-2 rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent sm:w-auto"
    >
      <Download size={17} />
      {label}
    </button>
  );
}
