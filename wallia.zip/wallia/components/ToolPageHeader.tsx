import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function ToolPageHeader({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <Link
        href="/ferramentas"
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-mist-400 hover:text-ink-950"
      >
        <ArrowLeft size={15} />
        Todas as ferramentas
      </Link>
      <h1 className="text-3xl font-semibold tracking-tight text-ink-950 sm:text-4xl">
        {title}
      </h1>
      <p className="mt-3 text-base text-mist-400">{description}</p>
    </div>
  );
}
