"use client";

import { useCallback, useRef, useState, type ChangeEvent, type DragEvent } from "react";
import { UploadCloud } from "lucide-react";
import { MAX_FILE_SIZE_BYTES, formatBytes } from "@/lib/tools";

interface FileUploaderProps {
  accept: string;
  multiple?: boolean;
  onFilesSelected: (files: File[]) => void;
  onError: (message: string) => void;
  label?: string;
  hint?: string;
}

function isAcceptedType(file: File, accept: string): boolean {
  const accepted = accept.split(",").map((a) => a.trim().toLowerCase());
  const name = file.name.toLowerCase();
  const type = file.type.toLowerCase();
  return accepted.some((a) => {
    if (a.startsWith(".")) return name.endsWith(a);
    return type === a;
  });
}

export default function FileUploader({
  accept,
  multiple = false,
  onFilesSelected,
  onError,
  label = "Arraste seus arquivos aqui",
  hint,
}: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateAndEmit = useCallback(
    (fileList: FileList | null) => {
      if (!fileList || fileList.length === 0) return;
      const files = Array.from(fileList);

      for (const file of files) {
        if (!isAcceptedType(file, accept)) {
          onError(`"${file.name}" não é um tipo de arquivo aceito (${accept}).`);
          return;
        }
        if (file.size > MAX_FILE_SIZE_BYTES) {
          onError(
            `"${file.name}" excede o limite permitido de ${formatBytes(MAX_FILE_SIZE_BYTES)}.`
          );
          return;
        }
      }

      onFilesSelected(multiple ? files : [files[0]]);
    },
    [accept, multiple, onError, onFilesSelected]
  );

  return (
    <div
      onDragOver={(e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={(e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragging(false);
        validateAndEmit(e.dataTransfer.files);
      }}
      className={`flex flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-14 text-center transition-colors ${
        isDragging
          ? "border-accent bg-accent/5"
          : "border-ink-800/15 bg-ink-950/[0.015]"
      }`}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-ink-950/[0.04] text-ink-950">
        <UploadCloud size={26} strokeWidth={1.5} />
      </div>

      <p className="mt-4 hidden text-base font-medium text-ink-800 sm:block">
        {label}
      </p>
      <p className="mt-1 hidden text-sm text-mist-400 sm:block">ou</p>

      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="mt-4 w-full max-w-xs rounded-full bg-ink-950 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-accent sm:w-auto"
      >
        Selecionar arquivos
      </button>

      {hint && <p className="mt-4 text-xs text-mist-400">{hint}</p>}

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="sr-only"
        aria-label="Selecionar arquivos"
        onChange={(e: ChangeEvent<HTMLInputElement>) => {
          validateAndEmit(e.target.files);
          e.target.value = "";
        }}
      />
    </div>
  );
}
