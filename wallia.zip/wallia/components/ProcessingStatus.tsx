import { Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import type { ProcessingState } from "@/types";

export default function ProcessingStatus({ state }: { state: ProcessingState }) {
  if (state.status === "idle") return null;

  if (state.status === "processing") {
    return (
      <div
        role="status"
        aria-live="polite"
        className="mt-6 flex items-center gap-3 rounded-xl border border-ink-800/10 bg-ink-950/[0.02] px-4 py-3.5"
      >
        <Loader2 size={18} className="animate-spin text-accent" />
        <div className="flex-1">
          <p className="text-sm font-medium text-ink-900">{state.message}</p>
          {typeof state.progress === "number" && (
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-800/10">
              <div
                className="h-full rounded-full bg-accent transition-all"
                style={{ width: `${Math.round(state.progress * 100)}%` }}
              />
            </div>
          )}
        </div>
      </div>
    );
  }

  if (state.status === "done") {
    return (
      <div
        role="status"
        className="mt-6 flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3.5"
      >
        <CheckCircle2 size={18} className="text-emerald-600" />
        <p className="text-sm font-medium text-emerald-800">{state.message}</p>
      </div>
    );
  }

  return (
    <div
      role="alert"
      className="mt-6 flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3.5"
    >
      <AlertTriangle size={18} className="flex-shrink-0 text-red-600" />
      <p className="text-sm font-medium text-red-800">{state.message}</p>
    </div>
  );
}
