export interface ManagedFile {
  id: string;
  file: File;
}

export interface ToolDefinition {
  slug: string;
  title: string;
  description: string;
  category: "pdf" | "imagem" | "documentos" | "texto";
  available: boolean;
}

export type ProcessingState =
  | { status: "idle" }
  | { status: "processing"; message: string; progress?: number }
  | { status: "done"; message: string }
  | { status: "error"; message: string };
