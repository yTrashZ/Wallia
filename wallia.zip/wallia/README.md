# Wall.IA

Ferramentas digitais. Simples e rápidas.

Plataforma de ferramentas online para documentos, começando por PDF. As
ferramentas processam os arquivos diretamente no navegador do usuário sempre
que tecnicamente possível.

## Rodando localmente

Pré-requisitos: Node.js 18.18+ (recomendado 20 LTS) e npm.

```bash
npm install
npm run dev
```

Acesse http://localhost:3000

## Build de produção

```bash
npm run build
npm run start
```

## Publicando na Vercel

1. Suba este projeto para um repositório Git (GitHub, GitLab ou Bitbucket).
2. Em https://vercel.com, clique em "Add New Project" e importe o repositório.
3. A Vercel detecta automaticamente que é um projeto Next.js — não é
   necessário configurar nada manualmente (build command `next build`,
   output gerenciado pela própria Vercel).
4. Clique em "Deploy".

Não há variáveis de ambiente obrigatórias nesta primeira versão.

## Ferramentas implementadas (funcionais de verdade, 100% no navegador)

- Juntar PDF (`pdf-lib`)
- Dividir PDF (`pdf-lib`)
- Comprimir PDF — compressão real via remoção de metadados e reconstrução
  com object streams (`pdf-lib`). Ver limitação explicada na própria página.
- PDF para JPG (`pdfjs-dist` + `canvas`, empacotado em `.zip` com `jszip`
  quando há mais de uma página)
- JPG para PDF (`pdf-lib`, aceita JPG/JPEG/PNG/WEBP)
- Girar PDF (`pdf-lib`)
- Remover páginas (`pdf-lib`)
- Extrair páginas (`pdf-lib`)

## Estrutura

```
app/                     rotas (App Router)
  ferramentas/<slug>/    uma página por ferramenta
components/              componentes reutilizáveis (upload, lista, status...)
lib/pdf/                 lógica real de processamento de PDF
lib/tools.ts             definição central das ferramentas
types/                   tipos compartilhados
```
