import type { ToolDefinition } from "@/types";

export const tools: ToolDefinition[] = [
  {
    slug: "juntar-pdf",
    title: "Juntar PDF",
    description: "Combine vários arquivos PDF em um único documento.",
    category: "pdf",
    available: true,
  },
  {
    slug: "dividir-pdf",
    title: "Dividir PDF",
    description: "Separe páginas específicas de um arquivo PDF.",
    category: "pdf",
    available: true,
  },
  {
    slug: "comprimir-pdf",
    title: "Comprimir PDF",
    description: "Reduza o tamanho do seu PDF mantendo a qualidade.",
    category: "pdf",
    available: true,
  },
  {
    slug: "pdf-para-jpg",
    title: "PDF para JPG",
    description: "Converta páginas do PDF em imagens JPG.",
    category: "pdf",
    available: true,
  },
  {
    slug: "jpg-para-pdf",
    title: "JPG para PDF",
    description: "Transforme imagens em um documento PDF.",
    category: "pdf",
    available: true,
  },
  {
    slug: "girar-pdf",
    title: "Girar PDF",
    description: "Gire páginas do seu PDF facilmente.",
    category: "pdf",
    available: true,
  },
  {
    slug: "remover-paginas",
    title: "Remover páginas",
    description: "Remova páginas desnecessárias do seu documento.",
    category: "pdf",
    available: true,
  },
  {
    slug: "extrair-paginas",
    title: "Extrair páginas",
    description: "Extraia páginas específicas e crie um novo PDF.",
    category: "pdf",
    available: true,
  },
];

export function getToolBySlug(slug: string): ToolDefinition | undefined {
  return tools.find((t) => t.slug === slug);
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  const value = bytes / Math.pow(1024, i);
  return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

export const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB
