import { PDFDocument } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

/**
 * Converte PNG/WEBP para JPEG usando canvas (pdf-lib só embute JPEG ou PNG
 * nativamente; WEBP precisa ser reconvertido no navegador antes de embutir).
 */
async function toEmbeddableBytes(
  file: File
): Promise<{ bytes: ArrayBuffer; kind: "jpg" | "png" }> {
  const type = file.type.toLowerCase();

  if (type === "image/jpeg" || type === "image/jpg") {
    return { bytes: await file.arrayBuffer(), kind: "jpg" };
  }
  if (type === "image/png") {
    return { bytes: await file.arrayBuffer(), kind: "png" };
  }

  // WEBP (ou outros formatos suportados pelo <img>) -> recodifica para JPEG.
  const imgBitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = imgBitmap.width;
  canvas.height = imgBitmap.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Seu dispositivo não conseguiu concluir o processamento.");
  ctx.drawImage(imgBitmap, 0, 0);

  const blob: Blob = await new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("Falha ao converter imagem."))),
      "image/jpeg",
      0.92
    );
  });

  return { bytes: await blob.arrayBuffer(), kind: "jpg" };
}

/**
 * Cria um PDF real com uma página por imagem, na ordem fornecida.
 * Cada página é dimensionada para caber a imagem em uma folha A4,
 * preservando a proporção original.
 */
export async function imagesToPdf(files: File[]): Promise<Blob> {
  if (files.length === 0) {
    throw new Error("Selecione ao menos uma imagem.");
  }

  const doc = await PDFDocument.create();
  const A4_WIDTH = 595.28;
  const A4_HEIGHT = 841.89;

  for (const file of files) {
    let embedded;
    try {
      const { bytes, kind } = await toEmbeddableBytes(file);
      embedded = kind === "jpg" ? await doc.embedJpg(bytes) : await doc.embedPng(bytes);
    } catch {
      throw new Error(`"${file.name}" não pôde ser processada como imagem.`);
    }

    const margin = 24;
    const maxW = A4_WIDTH - margin * 2;
    const maxH = A4_HEIGHT - margin * 2;
    const scale = Math.min(maxW / embedded.width, maxH / embedded.height, 1);
    const drawW = embedded.width * scale;
    const drawH = embedded.height * scale;

    const page = doc.addPage([A4_WIDTH, A4_HEIGHT]);
    page.drawImage(embedded, {
      x: (A4_WIDTH - drawW) / 2,
      y: (A4_HEIGHT - drawH) / 2,
      width: drawW,
      height: drawH,
    });
  }

  const outBytes = await doc.save();
  return bytesToBlob(outBytes, "application/pdf");
}
