import { splitPdf } from "./split";

/**
 * Extrai páginas específicas para um novo PDF.
 * Funcionalmente idêntico a "dividir", mas exposto como função própria
 * para manter a ferramenta "Extrair páginas" semanticamente clara.
 */
export async function extractPages(file: File, pages1Based: number[]): Promise<Blob> {
  return splitPdf(file, pages1Based);
}
