import JSZip from "jszip";

// pdfjs-dist é carregado dinamicamente (import() ) para não engordar o bundle
// de páginas que não usam essa ferramenta, e porque depende do objeto `window`.
async function loadPdfjs() {
  const pdfjs = await import("pdfjs-dist");
  // O worker precisa ser servido como asset estático; usamos a versão do próprio pacote.
  pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    "pdfjs-dist/build/pdf.worker.min.mjs",
    import.meta.url
  ).toString();
  return pdfjs;
}

export interface PdfToImagesResult {
  blob: Blob;
  filename: string;
  isZip: boolean;
  pageCount: number;
}

/**
 * Converte páginas de um PDF em imagens JPG.
 * pages1Based = null significa "todas as páginas".
 * Se houver mais de uma imagem resultante, elas são empacotadas em um .zip.
 */
export async function pdfToImages(
  file: File,
  pages1Based: number[] | null,
  onProgress?: (fraction: number) => void
): Promise<PdfToImagesResult> {
  const pdfjs = await loadPdfjs();
  const bytes = await file.arrayBuffer();

  let pdf;
  try {
    pdf = await pdfjs.getDocument({ data: bytes }).promise;
  } catch {
    throw new Error("Este arquivo não é um PDF válido.");
  }

  const total = pdf.numPages;
  const targets =
    pages1Based && pages1Based.length > 0
      ? pages1Based.filter((p) => p >= 1 && p <= total)
      : Array.from({ length: total }, (_, i) => i + 1);

  if (targets.length === 0) {
    throw new Error("Nenhuma página válida foi selecionada.");
  }

  const baseName = file.name.replace(/\.pdf$/i, "");
  const images: { name: string; blob: Blob }[] = [];

  for (let i = 0; i < targets.length; i++) {
    const pageNum = targets[i];
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: 2 });

    const canvas = document.createElement("canvas");
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Seu dispositivo não conseguiu concluir o processamento.");

    await page.render({ canvas, canvasContext: ctx, viewport }).promise;

    const blob: Blob = await new Promise((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error("Falha ao gerar imagem."))),
        "image/jpeg",
        0.92
      );
    });

    images.push({ name: `${baseName}-pagina-${pageNum}.jpg`, blob });
    onProgress?.((i + 1) / targets.length);
  }

  if (images.length === 1) {
    return {
      blob: images[0].blob,
      filename: images[0].name,
      isZip: false,
      pageCount: 1,
    };
  }

  const zip = new JSZip();
  for (const img of images) {
    zip.file(img.name, img.blob);
  }
  const zipBlob = await zip.generateAsync({ type: "blob" });

  return {
    blob: zipBlob,
    filename: `${baseName}-paginas.zip`,
    isZip: true,
    pageCount: images.length,
  };
}
