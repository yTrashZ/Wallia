import { PDFDocument, degrees } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

/**
 * Gira páginas do PDF pelo ângulo informado (90, 180 ou 270).
 * Se pages1Based for null/vazio, gira todas as páginas.
 */
export async function rotatePdf(
  file: File,
  angle: 90 | 180 | 270,
  pages1Based: number[] | null
): Promise<Blob> {
  const bytes = await file.arrayBuffer();
  let doc: PDFDocument;
  try {
    doc = await PDFDocument.load(bytes);
  } catch {
    throw new Error("Este arquivo não é um PDF válido.");
  }

  const total = doc.getPageCount();
  const targets =
    pages1Based && pages1Based.length > 0
      ? pages1Based.filter((p) => p >= 1 && p <= total).map((p) => p - 1)
      : Array.from({ length: total }, (_, i) => i);

  for (const idx of targets) {
    const page = doc.getPage(idx);
    const current = page.getRotation().angle;
    page.setRotation(degrees((current + angle) % 360));
  }

  const outBytes = await doc.save();
  return bytesToBlob(outBytes, "application/pdf");
}
