/**
 * Converte o Uint8Array retornado por pdf-lib/pdfjs em um Blob.
 * Faz uma cópia para um ArrayBuffer "puro", evitando problemas de tipagem
 * (Uint8Array pode ser genérico sobre ArrayBufferLike, que inclui
 * SharedArrayBuffer, não aceito diretamente como BlobPart) e garantindo
 * que o buffer resultante corresponda exatamente aos bytes do PDF.
 */
export function bytesToBlob(bytes: Uint8Array, type: string): Blob {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return new Blob([copy.buffer as ArrayBuffer], { type });
}
