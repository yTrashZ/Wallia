import { PDFDocument } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

/**
 * Junta múltiplos arquivos PDF, na ordem fornecida, em um único PDF novo.
 * Os arquivos originais não são modificados (lidos apenas como ArrayBuffer).
 */
export async function mergePdfs(
  files: File[],
  onProgress?: (fraction: number) => void
): Promise<Blob> {
  if (files.length < 2) {
    throw new Error("Selecione pelo menos dois arquivos PDF para juntar.");
  }

  const merged = await PDFDocument.create();

  for (let i = 0; i < files.length; i++) {
    const bytes = await files[i].arrayBuffer();
    let doc: PDFDocument;
    try {
      doc = await PDFDocument.load(bytes);
    } catch {
      throw new Error(`"${files[i].name}" não é um PDF válido.`);
    }
    const pageIndices = doc.getPageIndices();
    const copiedPages = await merged.copyPages(doc, pageIndices);
    copiedPages.forEach((page) => merged.addPage(page));
    onProgress?.((i + 1) / files.length);
  }

  const outBytes = await merged.save();
  return bytesToBlob(outBytes, "application/pdf");
}
