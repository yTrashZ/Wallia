import { PDFDocument } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

export async function getPdfPageCount(file: File): Promise<number> {
  const bytes = await file.arrayBuffer();
  const doc = await PDFDocument.load(bytes);
  return doc.getPageCount();
}

/**
 * Gera um novo PDF contendo apenas as páginas informadas (índices baseados em 1).
 */
export async function splitPdf(file: File, pages1Based: number[]): Promise<Blob> {
  const bytes = await file.arrayBuffer();
  let src: PDFDocument;
  try {
    src = await PDFDocument.load(bytes);
  } catch {
    throw new Error("Este arquivo não é um PDF válido.");
  }

  const total = src.getPageCount();
  const zeroBased = pages1Based
    .filter((p) => p >= 1 && p <= total)
    .map((p) => p - 1);

  if (zeroBased.length === 0) {
    throw new Error("Nenhuma página válida foi selecionada.");
  }

  const out = await PDFDocument.create();
  const copied = await out.copyPages(src, zeroBased);
  copied.forEach((page) => out.addPage(page));

  const outBytes = await out.save();
  return bytesToBlob(outBytes, "application/pdf");
}
