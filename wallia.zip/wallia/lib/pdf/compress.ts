import { PDFDocument } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

export interface CompressResult {
  blob: Blob;
  originalSize: number;
  finalSize: number;
}

/**
 * Compressão real executada inteiramente no navegador.
 *
 * LIMITAÇÃO HONESTA: sem uma biblioteca de recompressão de imagens (o que exigiria
 * decodificar e reduzir cada imagem interna do PDF, algo pesado para rodar 100%
 * client-side com qualidade previsível), não é possível garantir uma redução
 * agressiva de tamanho como fazem serviços de servidor especializados.
 *
 * O que esta função faz de verdade:
 * - Remove metadados desnecessários (autor, produtor, datas, palavras-chave).
 * - Reconstrói o PDF usando "object streams", que geralmente reduz a sobrecarga
 *   de estrutura interna do arquivo.
 * - Retorna o tamanho real antes/depois — nunca uma porcentagem inventada.
 *
 * PDFs que já estão otimizados (ou compostos majoritariamente por texto) podem
 * apresentar pouca ou nenhuma redução. Isso é mostrado claramente ao usuário.
 */
export async function compressPdf(file: File): Promise<CompressResult> {
  const originalSize = file.size;
  const bytes = await file.arrayBuffer();

  let doc: PDFDocument;
  try {
    doc = await PDFDocument.load(bytes, { updateMetadata: false });
  } catch {
    throw new Error("Este arquivo não é um PDF válido.");
  }

  doc.setTitle("");
  doc.setAuthor("");
  doc.setSubject("");
  doc.setKeywords([]);
  doc.setProducer("");
  doc.setCreator("");

  const outBytes = await doc.save({ useObjectStreams: true });
  const blob = bytesToBlob(outBytes, "application/pdf");

  return {
    blob,
    originalSize,
    finalSize: blob.size,
  };
}
