import { PDFDocument } from "pdf-lib";
import { bytesToBlob } from "./bytesToBlob";

/**
 * Gera um novo PDF removendo as páginas informadas (índices baseados em 1).
 */
export async function removePagesFromPdf(
  file: File,
  pagesToRemove1Based: number[]
): Promise<Blob> {
  const bytes = await file.arrayBuffer();
  let doc: PDFDocument;
  try {
    doc = await PDFDocument.load(bytes);
  } catch {
    throw new Error("Este arquivo não é um PDF válido.");
  }

  const total = doc.getPageCount();
  const removeSet = new Set(pagesToRemove1Based);

  if (removeSet.size >= total) {
    throw new Error("Não é possível remover todas as páginas do documento.");
  }

  // Remove de trás para frente para não deslocar os índices restantes.
  for (let i = total; i >= 1; i--) {
    if (removeSet.has(i)) {
      doc.removePage(i - 1);
    }
  }

  const outBytes = await doc.save();
  return bytesToBlob(outBytes, "application/pdf");
}
