/**
 * Converte uma string como "1-5, 8, 10-12" em uma lista de índices de página
 * baseados em 1 (como o usuário vê), validando contra o total de páginas.
 * Lança um Error com mensagem amigável quando a entrada é inválida.
 */
export function parsePageRanges(input: string, totalPages: number): number[] {
  const cleaned = input.trim();
  if (!cleaned) {
    throw new Error("Informe ao menos uma página ou intervalo.");
  }

  const parts = cleaned.split(",").map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0) {
    throw new Error("Informe ao menos uma página ou intervalo.");
  }

  const pages = new Set<number>();

  for (const part of parts) {
    const rangeMatch = part.match(/^(\d+)\s*-\s*(\d+)$/);
    const singleMatch = part.match(/^(\d+)$/);

    if (rangeMatch) {
      const start = parseInt(rangeMatch[1], 10);
      const end = parseInt(rangeMatch[2], 10);
      if (start < 1 || end < 1 || start > end) {
        throw new Error(`Intervalo inválido: "${part}".`);
      }
      if (start > totalPages || end > totalPages) {
        throw new Error(
          `O intervalo "${part}" ultrapassa o total de páginas (${totalPages}).`
        );
      }
      for (let i = start; i <= end; i++) pages.add(i);
    } else if (singleMatch) {
      const n = parseInt(singleMatch[1], 10);
      if (n < 1 || n > totalPages) {
        throw new Error(
          `A página ${n} não existe neste documento (total: ${totalPages}).`
        );
      }
      pages.add(n);
    } else {
      throw new Error(`Formato não reconhecido: "${part}". Use algo como 1-3, 5, 8-10.`);
    }
  }

  return Array.from(pages).sort((a, b) => a - b);
}
