import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#08090b",
          900: "#0d0e11",
          800: "#16181d",
          700: "#22252c",
          600: "#33363f",
        },
        mist: {
          400: "#8a8f9c",
          300: "#a9adb8",
          200: "#c9ccd3",
          100: "#e7e8ec",
          50: "#f6f6f8",
        },
        accent: {
          DEFAULT: "#5b5bf0",
          light: "#7d7dff",
          dark: "#4444c7",
        },
      },
      fontFamily: {
        sans: [
          "var(--font-sans)",
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
        ],
      },
      boxShadow: {
        card: "0 1px 2px rgba(8,9,11,0.04), 0 8px 24px -12px rgba(8,9,11,0.12)",
      },
      maxWidth: {
        content: "1180px",
      },
    },
  },
  plugins: [],
};

export default config;
